## Full name

## What should we call you? (optional)
For example, a shortened name or a name you prefer.

## What would you like to find out about?
- Fostering
- Adoption
- I'm not sure yet

## Are you asking about a child you already know?
For example, a grandchild, niece, nephew or a family friend's child. This is often called kinship or relative care. A different team helps with it. Don't tell us anything about the child here.
- Yes
- No

## How would you like us to contact you?
- Email
- Phone call
- Text message

## What is your email address?
We'll only use this to reply to you.

## What is your phone number?
For example, 202-555-0147.

## When is a good time to call? (optional)
Select all that apply. We'll try to call at these times.
- Weekday mornings
- Weekday afternoons
- Weekday evenings
- Saturdays

## What are the first 3 digits of your ZIP code? (optional)
For example, 123. We only need the first 3 digits to find your local agency. We won't ask for your address.

## What would you like to talk about? (optional)
Select all that apply. You can also tell us when we talk. Please don't share personal details here.
- Whether I can foster or adopt
- What it involves day to day
- Money and support
- The steps and how long they take
- Different types of care
- Something else

## How did you hear about us? (optional)
- A friend or family member
- Social media
- An internet search
- An event
- An ad
- A state or agency website
- Somewhere else

## Would you like updates and invitations to events? (optional)
We'll only send these if you check the box. You can stop them at any time.
- Yes, send me updates and event invitations
