## Full name

## What should we call you? (optional)
For example, a shortened name or a name you prefer.

## What would you like to find out about?
- Becoming a caregiver (foster care)
- Adoption
- I'm not sure yet

## Are you asking about a child you already know?
For example, a child in your whānau (family), like a grandchild, niece or nephew, or a friend's child. This is called whānau care. A different team helps with it. Do not tell us anything about the child here.
- Yes
- No

## How would you like us to contact you?
- Email
- Phone call
- Text message

## What is your email address?
We'll only use this to reply to you.

## What is your phone number?
For example, 021 000 0000.

## When is a good time to call? (optional)
Select all that apply. We'll try to call at these times.
- Weekday mornings
- Weekday afternoons
- Weekday evenings
- Saturdays

## What is your postcode? (optional)
For example, 6011. We use it to find the nearest Oranga Tamariki (Ministry for Children) site or care partner. We will not ask for your address.

## What would you like to talk about? (optional)
Select all that apply. You can also tell us when we talk. Do not share personal details here.
- Whether I can be a caregiver or adopt
- What it involves day to day
- Money and support
- The steps and how long they take
- Different types of care
- Something else

## How did you hear about us? (optional)
- A friend or whānau member
- Social media
- An internet search
- An event
- An advert
- An agency, iwi (tribe) or government website
- Somewhere else

## Would you like updates and invitations to events? (optional)
We'll only send these if you tick the box. You can stop them at any time.
- Yes, send me updates and event invitations
