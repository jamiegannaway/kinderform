## Nombre y apellidos

## ¿Cómo quiere que le llamemos? (opcional)
Por ejemplo, un nombre más corto o el nombre que prefiera.

## ¿Sobre qué quiere informarse?
- Acogimiento familiar
- Adopción
- Todavía no lo sé

## ¿Pregunta por un niño o una niña de su familia o de su entorno?
Por ejemplo, un nieto o una nieta, un sobrino o una sobrina, o el hijo o la hija de alguien cercano. Si es de su familia, se llama acogimiento en familia extensa. Le atiende otro equipo. No nos cuente aquí nada sobre el niño o la niña.
- Sí
- No

## ¿Cómo quiere que nos pongamos en contacto con usted?
- Correo electrónico
- Llamada de teléfono
- Mensaje de texto (SMS)

## ¿Cuál es su correo electrónico?
Solo lo usaremos para responderle.

## ¿Cuál es su número de teléfono?
Por ejemplo, 600 000 000.

## ¿Cuándo le viene bien que le llamemos? (opcional)
Elija todas las opciones que quiera. Intentaremos llamarle en esos momentos.
- Mañanas entre semana
- Tardes entre semana
- A última hora de la tarde entre semana
- Sábados

## ¿Cuál es su código postal? (opcional)
Por ejemplo, 28001. El código postal nos dice qué servicio le responde. No le pediremos su dirección.

## ¿De qué le gustaría hablar? (opcional)
Elija todas las opciones que quiera. También nos lo puede contar cuando hablemos. No comparta aquí datos personales.
- Si puedo acoger o adoptar
- Cómo es el día a día
- Ayudas económicas y apoyo
- Los pasos y cuánto tardan
- Los tipos de acogimiento
- Otra cosa

## ¿Cómo nos ha conocido? (opcional)
- Por una amistad o un familiar
- Por las redes sociales
- Buscando en internet
- En una charla o un evento
- Por un anuncio
- En la web de un servicio público
- De otra forma

## ¿Quiere recibir novedades e invitaciones a eventos? (opcional)
Solo se las enviaremos si marca la casilla. Puede darse de baja cuando quiera.
- Sí, quiero recibir novedades e invitaciones a eventos
