## Voornaam en achternaam

## Hoe mogen we je noemen? (niet verplicht)
Bijvoorbeeld een korte naam of een naam die je liever hebt.

## Waar wil je meer over weten?
- Pleegzorg
- Adoptie
- Dat weet ik nog niet

## Gaat je vraag over een kind dat je al kent?
Bijvoorbeeld een kleinkind, nichtje, neefje of het kind van vrienden. Dat heet netwerkpleegzorg. Een ander team helpt je daarbij. Schrijf hier niets over het kind.
- Ja
- Nee

## Hoe wil je dat we contact met je opnemen?
- Per e-mail
- Per telefoon
- Per sms

## Wat is je e-mailadres?
We gebruiken het alleen om je te antwoorden.

## Wat is je telefoonnummer?
Bijvoorbeeld 06 12345678.

## Wanneer kunnen we je het beste bellen? (niet verplicht)
Kies alles wat past. We proberen je op die momenten te bellen.
- Doordeweeks ’s ochtends
- Doordeweeks ’s middags
- Doordeweeks ’s avonds
- Op zaterdag

## Wat zijn de 4 cijfers van je postcode? (niet verplicht)
Bijvoorbeeld 1234. Alleen de cijfers, zonder de letters. Zo weten we welke pleegzorgorganisatie bij jou in de buurt werkt. We vragen niet naar je adres.

## Waar wil je over praten? (niet verplicht)
Kies alles wat past. Je kunt het ons ook in het gesprek vertellen. Schrijf hier niets persoonlijks.
- Of ik pleegouder kan worden of een kind kan adopteren
- Hoe het dagelijks leven eruitziet
- Geld en hulp
- De stappen en hoe lang ze duren
- De verschillende vormen van pleegzorg
- Iets anders

## Hoe heb je over ons gehoord? (niet verplicht)
- Via vrienden of familie
- Via sociale media
- Via een zoekmachine
- Op een bijeenkomst
- Via een advertentie
- Via de website van mijn gemeente
- Op een andere manier

## Wil je nieuws en uitnodigingen voor bijeenkomsten krijgen? (niet verplicht)
We sturen ze alleen als je het vakje aanvinkt. Je kunt je altijd weer afmelden.
- Ja, stuur me nieuws en uitnodigingen
