## Prénom et nom

## Comment voulez-vous que l'on vous appelle ? (facultatif)
Par exemple, un diminutif ou un prénom que vous préférez.

## Sur quoi voulez-vous vous renseigner ?
- Devenir famille d'accueil (assistant familial)
- Adopter
- Je ne sais pas encore

## Votre demande concerne-t-elle un enfant de votre famille ou de votre entourage ?
Par exemple, un petit-enfant, une nièce, un neveu ou l'enfant d'un ami. On parle alors d'accueil par un proche. Une autre équipe s'en occupe. Ne donnez ici aucune information sur l'enfant.
- Oui
- Non

## Comment voulez-vous que nous vous contactions ?
- Par e-mail
- Par téléphone
- Par SMS

## Quelle est votre adresse e-mail ?
Nous l'utiliserons seulement pour vous répondre.

## Quel est votre numéro de téléphone ?
Par exemple, 06 39 98 12 34.

## À quel moment pouvons-nous vous appeler ? (facultatif)
Choisissez tous les moments qui vous conviennent. Nous essaierons d'appeler à ces moments.
- En semaine, le matin
- En semaine, l'après-midi
- En semaine, le soir
- Le samedi

## Quel est votre code postal ? (facultatif)
Par exemple, 35000. Le code postal nous dit dans quel département vous vivez. C'est le conseil départemental qui vous répondra. Nous ne vous demanderons pas votre adresse.

## De quoi voulez-vous parler ? (facultatif)
Choisissez tout ce qui vous intéresse. Vous pourrez aussi en parler pendant l'échange. Ne donnez pas d'informations personnelles ici.
- Si je peux devenir famille d'accueil ou adopter
- Ce que cela représente au quotidien
- L'argent et l'accompagnement
- Les étapes et leur durée
- Les différents types d'accueil
- Autre chose

## Comment avez-vous entendu parler de nous ? (facultatif)
- Par un ami ou une personne de ma famille
- Par les réseaux sociaux
- Par une recherche sur internet
- Lors d'un événement
- Par une publicité
- Sur le site internet du département
- D'une autre façon

## Voulez-vous recevoir des nouvelles et des invitations à des événements ? (facultatif)
Nous vous en enverrons seulement si vous cochez la case. Vous pourrez arrêter à tout moment.
- Oui, envoyez-moi des nouvelles et des invitations
