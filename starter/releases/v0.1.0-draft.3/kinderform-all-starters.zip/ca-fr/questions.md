## Nom complet

## Comment devrions-nous vous appeler? (facultatif)
Par exemple, un diminutif ou un nom que vous préférez.

## Sur quoi aimeriez-vous vous renseigner?
- Devenir famille d'accueil
- L'adoption
- Je ne sais pas encore

## Votre demande concerne-t-elle un enfant que vous connaissez déjà?
Par exemple, un petit-enfant, une nièce, un neveu ou l'enfant d'une amie ou d'un ami. On parle alors de prise en charge par un proche. Une autre équipe s'en occupe. Ne nous donnez ici aucun renseignement sur l'enfant.
- Oui
- Non

## Comment aimeriez-vous que nous communiquions avec vous?
- Par courriel
- Par téléphone
- Par message texte

## Quelle est votre adresse courriel?
Nous l'utiliserons seulement pour vous répondre.

## Quel est votre numéro de téléphone?
Par exemple, 613-555-0199.

## Quel est le meilleur moment pour vous appeler? (facultatif)
Choisissez tout ce qui s'applique. Nous essaierons d'appeler à ces moments.
- En semaine, le matin
- En semaine, l'après-midi
- En semaine, le soir
- Le samedi

## Dans quelle langue officielle voulez-vous que nous vous répondions? (facultatif)
Nous pouvons vous répondre en français ou en anglais.
- Anglais (English)
- Français

## Quels sont les 3 premiers caractères de votre code postal? (facultatif)
Par exemple, H0H ou K1A. Nous avons seulement besoin de la première partie pour trouver l'agence de votre région. Nous ne vous demanderons pas votre adresse.

## De quoi aimeriez-vous parler? (facultatif)
Choisissez tout ce qui s'applique. Vous pourrez aussi nous en parler pendant la conversation. Ne donnez pas de renseignements personnels ici.
- Si je peux devenir famille d'accueil ou adopter
- Ce que cela représente au quotidien
- L'aide financière et le soutien
- Les étapes et leur durée
- Les différents types de placement
- Autre chose

## Comment avez-vous entendu parler de nous? (facultatif)
- Par une amie, un ami ou un membre de ma famille
- Par les médias sociaux
- Par une recherche sur Internet
- Lors d'un événement
- Par une publicité
- Par le site Web d'une agence ou d'un gouvernement
- Ailleurs

## Aimeriez-vous recevoir des nouvelles et des invitations à des événements? (facultatif)
Nous vous en enverrons seulement si vous cochez la case. Vous pourrez vous désabonner en tout temps.
- Oui, envoyez-moi des nouvelles et des invitations
