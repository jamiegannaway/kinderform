## Vor- und Nachname

## Wie sollen wir Sie nennen? (optional)
Zum Beispiel eine Kurzform oder ein Name, der Ihnen lieber ist.

## Worüber möchten Sie mehr erfahren?
- Ein Pflegekind aufnehmen
- Ein Kind adoptieren
- Ich weiß es noch nicht

## Fragen Sie nach einem Kind, das Sie schon kennen?
Zum Beispiel ein Enkelkind, eine Nichte, ein Neffe oder das Kind von Freunden. Das nennt man Verwandtenpflege. Dabei hilft ein anderes Team. Schreiben Sie hier nichts über das Kind.
- Ja
- Nein

## Wie sollen wir uns bei Ihnen melden?
- Per E-Mail
- Per Anruf
- Per SMS

## Wie lautet Ihre E-Mail-Adresse?
Wir nutzen sie nur, um Ihnen zu antworten.

## Wie lautet Ihre Telefonnummer?
Zum Beispiel 0123 4567890.

## Wann können wir Sie gut anrufen? (optional)
Wählen Sie alle passenden Zeiten aus. Wir versuchen, Sie zu diesen Zeiten anzurufen.
- Montag bis Freitag, vormittags
- Montag bis Freitag, nachmittags
- Montag bis Freitag, abends
- Samstags

## Wie lautet Ihre Postleitzahl? (optional)
Zum Beispiel 12345. Ihr Wohnort entscheidet, welches Jugendamt Ihnen antwortet. Nach Ihrer Adresse fragen wir nicht.

## Worüber möchten Sie sprechen? (optional)
Wählen Sie alles Passende aus. Sie können es uns auch im Gespräch sagen. Schreiben Sie hier nichts Persönliches.
- Ob ich ein Pflegekind aufnehmen oder ein Kind adoptieren kann
- Wie der Alltag aussieht
- Geld und Unterstützung
- Die einzelnen Schritte und wie lange sie dauern
- Verschiedene Formen der Pflege
- Etwas anderes

## Wie haben Sie von uns erfahren? (optional)
- Über Freunde oder Familie
- Über soziale Medien
- Über eine Suche im Internet
- Bei einer Veranstaltung
- Durch Werbung
- Über die Website meiner Stadt oder meines Landkreises
- Auf anderem Weg

## Möchten Sie Neuigkeiten und Einladungen zu Veranstaltungen bekommen? (optional)
Wir schicken sie Ihnen nur, wenn Sie das Kästchen ankreuzen. Sie können sie jederzeit abbestellen.
- Ja, schicken Sie mir Neuigkeiten und Einladungen
