## För- och efternamn

## Vad vill du att vi kallar dig? (frivilligt)
Till exempel ett kortare namn eller ett namn som du hellre använder.

## Vad vill du veta mer om?
- Att bli familjehem
- Att adoptera
- Jag vet inte ännu

## Gäller din fråga ett barn som du redan känner?
Till exempel ett barnbarn, ett syskonbarn eller ett barn till vänner. När ett barn flyttar till någon i sin släkt eller sitt nätverk kallas det nätverkshem. Ett annat team hjälper dig med det. Skriv inget om barnet här.
- Ja
- Nej

## Hur vill du att vi kontaktar dig?
- E-post
- Telefonsamtal
- Sms

## Vad är din e-postadress?
Vi använder den bara för att svara dig.

## Vad är ditt telefonnummer?
Till exempel 070-000 00 00.

## När passar det bäst att vi ringer? (frivilligt)
Välj alla tider som passar. Vi försöker ringa dig då.
- Vardagar på förmiddagen
- Vardagar på eftermiddagen
- Vardagar på kvällen
- Lördagar

## Vilka är de 3 första siffrorna i ditt postnummer? (frivilligt)
Till exempel 411. Då ser vi ungefär var du bor och vem som kan hjälpa dig. Du behöver inte skriva hela postnumret. Vi frågar inte efter din adress.

## Vad vill du prata om? (frivilligt)
Välj allt som passar. Du kan också berätta när vi pratar. Skriv inget personligt här.
- Om jag kan bli familjehem eller adoptera
- Hur vardagen ser ut
- Ersättning och stöd
- Stegen och hur lång tid de tar
- Olika sätt att vara familjehem
- Något annat

## Hur fick du höra talas om oss? (frivilligt)
- Av vänner eller familj
- I sociala medier
- När jag sökte på nätet
- På en informationsträff
- I en annons
- På kommunens webbplats
- På något annat sätt

## Vill du få nyheter och inbjudningar till träffar? (frivilligt)
Vi skickar dem bara om du kryssar i rutan. Du kan sluta få dem när du vill.
- Ja, skicka nyheter och inbjudningar till mig
