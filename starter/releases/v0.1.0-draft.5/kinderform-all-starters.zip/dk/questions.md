## Fulde navn

## Hvad skal vi kalde dig? (frivilligt)
For eksempel et kortere navn eller et navn, du hellere vil bruge.

## Hvad vil du gerne vide mere om?
- At blive plejefamilie
- Adoption
- Det ved jeg ikke endnu

## Spørger du om et barn, du allerede kender?
For eksempel et barnebarn, en niece, en nevø eller en vens barn. Så bliver du netværksplejefamilie. Et andet team hjælper med det. Skriv ikke noget om barnet her.
- Ja
- Nej

## Hvordan vil du gerne kontaktes?
- E-mail
- Telefonopkald
- Sms

## Hvad er din e-mailadresse?
Vi bruger den kun til at svare dig.

## Hvad er dit telefonnummer?
For eksempel 00 00 00 00.

## Hvornår passer det dig bedst, at vi ringer? (frivilligt)
Vælg alle, der passer. Vi prøver at ringe på de tidspunkter.
- Hverdage om formiddagen
- Hverdage om eftermiddagen
- Hverdage om aftenen
- Lørdage

## Hvad er dit postnummer? (frivilligt)
For eksempel 1234. Så ved vi, hvilket team der dækker dit område. Vi spørger ikke om din adresse.

## Hvad vil du gerne tale om? (frivilligt)
Vælg alle, der passer. Du kan også fortælle os det, når vi taler sammen. Skriv ikke noget personligt her.
- Om jeg kan blive plejefamilie eller adoptere
- Hvordan hverdagen er
- Penge og støtte
- Forløbet, og hvor lang tid det tager
- De forskellige slags plejefamilier
- Noget andet

## Hvor har du hørt om os? (frivilligt)
- Fra venner eller familie
- På sociale medier
- Ved at søge på nettet
- Til et arrangement
- I en annonce
- På en kommunes eller organisations hjemmeside
- Et andet sted

## Vil du have nyheder og invitationer til arrangementer? (frivilligt)
Vi sender dem kun, hvis du sætter kryds. Du kan altid framelde dig igen.
- Ja, send mig nyheder og invitationer
