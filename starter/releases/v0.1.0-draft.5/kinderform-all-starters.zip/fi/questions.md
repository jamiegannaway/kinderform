## Etunimi ja sukunimi

## Millä nimellä voimme puhutella sinua? (vapaaehtoinen)
Esimerkiksi lyhyempi nimi tai nimi, jota käytät mieluummin.

## Mistä haluat tietää lisää?
- Sijaisperheeksi ryhtymisestä
- Adoptiosta
- En tiedä vielä

## Kysytkö lapsesta, jonka tunnet jo?
Esimerkiksi lapsenlapsesi, sisaruksesi lapsi tai ystäväsi lapsi. Silloin kuulut lapsen läheisverkostoon, esimerkiksi sukulaisena. Sinua auttaa eri tiimi. Älä kirjoita tähän mitään lapsesta.
- Kyllä
- Ei

## Miten haluat, että otamme sinuun yhteyttä?
- Sähköpostilla
- Soittamalla
- Tekstiviestillä

## Mikä on sähköpostiosoitteesi?
Käytämme sitä vain, kun vastaamme sinulle.

## Mikä on puhelinnumerosi?
Esimerkiksi 040 000 0000.

## Milloin sinulle voi soittaa? (vapaaehtoinen)
Valitse kaikki sopivat. Yritämme soittaa näinä aikoina.
- Arkiaamuisin
- Arki-iltapäivisin
- Arki-iltaisin
- Lauantaisin

## Mitkä ovat postinumerosi 3 ensimmäistä numeroa? (vapaaehtoinen)
Esimerkiksi 001, jos postinumerosi on 00100. Niiden avulla tiedämme, mikä hyvinvointialue hoitaa asiaasi. Emme kysy osoitettasi.

## Mistä haluaisit puhua? (vapaaehtoinen)
Valitse kaikki sopivat. Voit kertoa niistä myös, kun puhumme. Älä kirjoita tähän henkilökohtaisia tietoja.
- Voinko ryhtyä sijaisperheeksi tai adoptoida lapsen
- Millaista arki on
- Raha ja tuki
- Vaiheet ja kuinka kauan ne kestävät
- Perhehoidon eri muodot, esimerkiksi tukiperhe
- Jokin muu asia

## Mistä kuulit meistä? (vapaaehtoinen)
- Ystävältä tai sukulaiselta
- Sosiaalisesta mediasta
- Hakukoneesta
- Tilaisuudesta
- Mainoksesta
- Hyvinvointialueen tai järjestön verkkosivuilta
- Muualta

## Haluatko uutisia ja kutsuja tilaisuuksiin? (vapaaehtoinen)
Lähetämme niitä vain, jos valitset tämän. Voit perua ne milloin tahansa.
- Kyllä, haluan uutisia ja kutsuja
