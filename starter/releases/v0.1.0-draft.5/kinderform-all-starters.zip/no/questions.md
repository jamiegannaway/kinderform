## Fullt navn

## Hva vil du at vi skal kalle deg? (valgfritt)
For eksempel et kortere navn eller et navn du liker bedre.

## Hva vil du vite mer om?
- Å bli fosterhjem
- Adopsjon
- Jeg vet ikke ennå

## Gjelder spørsmålet ditt et barn du allerede kjenner?
For eksempel et barnebarn, en niese, en nevø eller barnet til en venn. Det kalles fosterhjem i slekt og nettverk. Et annet team hjelper deg med det. Ikke skriv noe om barnet her.
- Ja
- Nei

## Hvordan vil du at vi skal kontakte deg?
- På e-post
- På telefon
- På SMS

## Hva er e-postadressen din?
Vi bruker den bare til å svare deg.

## Hva er telefonnummeret ditt?
For eksempel 400 00 000.

## Når passer det best at vi ringer? (valgfritt)
Velg alt som passer. Vi prøver å ringe deg da.
- Hverdager på formiddagen
- Hverdager på ettermiddagen
- Hverdager på kvelden
- Lørdager

## Hva er postnummeret ditt? (valgfritt)
For eksempel 0150. Postnummeret viser oss hvilket kontor som skal svare deg. Vi spør ikke om adressen din.

## Hva vil du snakke om? (valgfritt)
Velg alt som passer. Du kan også si det når vi snakker sammen. Ikke skriv noe personlig her.
- Om jeg kan bli fosterhjem eller adoptere
- Hvordan hverdagen blir
- Penger og støtte
- Hva som skjer, og hvor lang tid det tar
- Ulike typer fosterhjem, som beredskapshjem
- Noe annet

## Hvordan hørte du om oss? (valgfritt)
- Fra venner eller familie
- I sosiale medier
- Gjennom et søk på nettet
- På et møte eller et arrangement
- Fra en annonse
- På nettsiden til kommunen eller staten
- På en annen måte

## Vil du ha nyheter og invitasjoner til møter? (valgfritt)
Vi sender dem bare hvis du krysser av. Du kan melde deg av når som helst.
- Ja, send meg nyheter og invitasjoner
